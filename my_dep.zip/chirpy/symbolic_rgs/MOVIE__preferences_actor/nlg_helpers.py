from chirpy.core.response_generator import nlg_helper, nlg_helper_augmented
import logging

logger = logging.getLogger('chirpylogger')
