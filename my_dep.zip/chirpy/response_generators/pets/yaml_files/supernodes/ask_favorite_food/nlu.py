def nlu_processing(rg, state, utterance, response_types):
	return {'unconditional': True}
