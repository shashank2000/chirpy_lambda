KEYWORD_MUSIC = [
    "music",
    "sing",
    "sings",
    "singing",
    "song",
    "songs",
    "singer",
    "instrument",
    "instruments",
    "melody",
    "composition"
]

FREQUENCY_ANSWERS = [
    "often",
    "sometimes",
    "always",
    "everyday",
    "a day",
    "every",
    "when",
]
