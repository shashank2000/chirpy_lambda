from .yes_template import YesTemplate, NotYesTemplate
from .disinterested_template import DisinterestedTemplate
from .change_topic_template import ChangeTopicTemplate
from .request_repeat import RequestRepeatTemplate
from .say_that_again_template import SayThatAgainTemplate
from .no_template import NoTemplate
