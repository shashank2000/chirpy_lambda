full-list-of-bad-words_text-file_2018_07_30.txt
    is from here: https://www.freewebheaders.com/full-list-of-bad-words-banned-by-google/
    it has about 1700 phrases
    apparently it's a third party reconstruction of what Google uses for SafeSearch
    don't edit this file directly; instead put your modifications in blacklists.py